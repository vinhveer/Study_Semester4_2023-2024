﻿namespace Bai6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Cau a: 9.5
            //Bill b = new Bill();
            //Console.Write($"{b.CalBill()}");

            // Cau b: error
            //Console.Write($"{b.price}");

            // Cau c: Acer 1 7.5
            //Bill b = new Bill("Acer", 1, 7.5f);
            //b.Print();

            // Cau d: Dell Latitude E7440 1 7.5
            //Bill b1 = new Bill();
            //Bill b2 = new Bill("Acer", 1, 7.5f);
            //b1.Print();
        }
    }
}
